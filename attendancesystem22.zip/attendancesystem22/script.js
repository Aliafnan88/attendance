const checkInBtn = document.getElementById("checkInBtn");
const checkOutBtn = document.getElementById("checkOutBtn");
const locationDisplay = document.getElementById("location");
const timeDisplay = document.getElementById("time");
const employeeNameInput = document.getElementById("employeeName");

// Function to get GEO location and display info
function getLocation(isCheckIn) {
  if (!employeeNameInput.value) {
    alert("Please enter employee name");
    return;
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition((position) => {
      const latitude = position.coords.latitude;
      const longitude = position.coords.longitude;

      // Get current time
      const currentTime = new Date().toLocaleString();

      // Get city name using reverse geocoding API (Here, using OpenStreetMap's API)
      const apiURL = `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`;

      fetch(apiURL)
        .then((response) => response.json())
        .then((data) => {
          const cityName =
            data.address.city ||
            data.address.town ||
            data.address.village ||
            "Unknown City";
          const name = employeeNameInput.value;

          // Display location and time
          if (isCheckIn) {
            locationDisplay.innerHTML = `Employee: ${name} <br> Check-In Location: Latitude: ${latitude}, Longitude: ${longitude} <br> City: ${cityName}`;
            timeDisplay.innerHTML = `Check-In Time: ${currentTime}`;
          } else {
            locationDisplay.innerHTML = `Employee: ${name} <br> Check-Out Location: Latitude: ${latitude}, Longitude: ${longitude} <br> City: ${cityName}`;
            timeDisplay.innerHTML = `Check-Out Time: ${currentTime}`;
          }

          // You can send this data to your backend here
          // fetch('/save-attendance', {
          //     method: 'POST',
          //     headers: {
          //         'Content-Type': 'application/json'
          //     },
          //     body: JSON.stringify({ name, latitude, longitude, cityName, currentTime, isCheckIn })
          // });
        })
        .catch((error) => {
          console.error("Error fetching city name: ", error);
        });
    }, showError);
  } else {
    locationDisplay.innerHTML = "Geolocation is not supported by this browser.";
  }
}

// Error callback for geolocation
function showError(error) {
  switch (error.code) {
    case error.PERMISSION_DENIED:
      locationDisplay.innerHTML = "User denied the request for Geolocation.";
      break;
    case error.POSITION_UNAVAILABLE:
      locationDisplay.innerHTML = "Location information is unavailable.";
      break;
    case error.TIMEOUT:
      locationDisplay.innerHTML = "The request to get user location timed out.";
      break;
    case error.UNKNOWN_ERROR:
      locationDisplay.innerHTML = "An unknown error occurred.";
      break;
  }
}

// Event listeners for Check-In and Check-Out buttons
checkInBtn.addEventListener("click", () => getLocation(true));
checkOutBtn.addEventListener("click", () => getLocation(false));
