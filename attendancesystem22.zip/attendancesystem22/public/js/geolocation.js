// if(navigator.geolocation) {
//     navigator.geolocation.getCurrentPosition(function(position) {
//         export const latitude = position.coords.latitude;
//         var longitude = position.coords.longitude;
//     });


// }
const checkInBtn = document.getElementById("checkInBtn");
const checkOutBtn = document.getElementById("checkOutBtn");
const employeeNameInput = document.getElementById("employeeName");

checkInBtn.addEventListener("click", () => {

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (position) {
      const latitude = position.coords.latitude;
      const longitude = position.coords.longitude;
      console.log(latitude);
      console.log(longitude);
      const currentdate = new Date();
      const intime = currentdate.getHours() + ":"
        + currentdate.getMinutes() + ":" + currentdate.getSeconds();
      const date = currentdate.getDay() + "/" + currentdate.getMonth()
        + "/" + currentdate.getFullYear();
      const apiURL = `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`;

      fetch(apiURL)
        .then((response) => response.json())
        .then((data) => {
          const city = data.city || data.address.city || "Unknown City"; // Fallback if city is not available
          const country = data.country || "Unknown Country"; // Fallback if country is not available

          const dataToPost = {
            latitude: latitude,
            longitude: longitude,
            name: employeeNameInput.value,
            intime: intime,
            date: date,
            city: city,
            country: country,
          };
          fetch('http://localhost:3000/checkin', { // Replace with your actual endpoint http://localhost:3000/checkin
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(dataToPost),
          })
        });
    });
  }

});

checkOutBtn.addEventListener("click", () => {
  const currentdate = new Date();
  const outtime = currentdate.getHours() + ":"
    + currentdate.getMinutes() + ":" + currentdate.getSeconds();

    const dataToPost = {
      name: employeeNameInput.value,
      outtime: outtime,
    };

    fetch('http://localhost:3000/checkout', { // Replace with your actual endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dataToPost),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        console.log('Success:', data);
        // Handle success (e.g., show a message to the user)
      })
      .catch((error) => {
        console.error('Error:', error);
        // Handle error (e.g., show an error message to the user)
      });
})


// const getCoordinates = () => {
//   return new Promise((resolve, reject) => {
//     if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition(
//         (position) => {
//           resolve({
//             latitude: position.coords.latitude,
//             longitude: position.coords.longitude,
//           });
//         },
//         (error) => {
//           reject(error);
//         }
//       );
//     } else {
//       reject(new Error("Geolocation is not supported by this browser."));
//     }
//   });
// };
// console.log(getCoordinates());
// exports = { getCoordinates };