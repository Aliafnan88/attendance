let express=require("express");
let app=express();
let port=3000;
let path=require("path");
let ejsMate = require('ejs-mate');
let mysql=require("mysql2");
let alert=require("alert-node");

app.set("view engine","ejs");
app.set("views",path.join(__dirname,"views"));
app.use(express.static(path.join(__dirname, "public")))
app.use(express.urlencoded({extended:true}));
app.engine('ejs',ejsMate);
app.use(express.json());

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    database: "employee",
    password: "ali1129",
  });

app.listen(port,()=>{
    console.log(`current port is ${port}`);
    // console.log(geolocation.longitude);
})

app.get("/login",(req,res)=>{
    res.render("main/index.ejs");
})
app.post("/login/Admin/Dashboard",(req,res)=>{
    let{admin:admin,password:password}=req.body;
    console.log(admin);
console.log(password);
    q=`select count(*) from employeeinfo`;
    if(admin=="Sarwar Nadeem" && password=="sarwar@123"){
        try{
            connection.query(q,(err,result)=>{
              if(err) throw err;
              let employee = result[0]["count(*)"];
              console.log(employee);
              res.render("main/dashboard.ejs",{employee});
            })
           }
           catch(err){
               console.log(err);
           }
    }
    else{
        alert("Please provide correct login details");
    } 
})
app.post("/checkin",(req,res)=>{
    let {longitude:longitude,latitude:latitude,name:name,intime:intime,city:city,country:country,date:date,totaltime:totaltime}=req.body;
    console.log(totaltime);
    console.log(name);
    if(name==""){
        res.redirect("/login");
        alert("Please provide employee name");
    }
    else{
        let attendance=[name,latitude,longitude,date,city,country,intime];
        let q=`insert into attendance(name,lattitude,longitude,date,city,country,intime) values(?,?,?,?,?,?,?)`;
        try{
            connection.query(q,attendance,(err,result)=>{
                if(err) throw err;
                console.log(result);
                res.redirect("/login");
                alert("attendance is marked");
            })
        }
        catch(err){
            console.log(err);
        }
    }
    
    
    // res.redirect("/login");
    
})

app.get("/Admin/Dashboard/Attendance",(req,res)=>{
    let q=`select *from attendance`;
    try{
     connection.query(q,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.render("main/attendance.ejs",{result})
     })
    }
    catch(err){
        console.log(err);
    }
    
})

app.post("/checkout", (req, res) => {
    let { name: name, outtime: outtime } = req.body;
    console.log(outtime);
    if(name==""){
        res.redirect("/login");
        alert("Please provide employee name");
    }
    else{
    let q = `UPDATE attendance SET outtime = ? WHERE name ='${name}'`;
    let value = [outtime];
  
    try {
      connection.query(q, value, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.redirect("/login");
        alert("Checkout successful");
      });
    } catch (err) {
      console.log(err);
    }
}
  });